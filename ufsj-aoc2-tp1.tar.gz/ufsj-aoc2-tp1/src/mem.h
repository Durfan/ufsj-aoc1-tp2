#ifndef SIMCACHE_MEM_H
#define SIMCACHE_MEM_H

void getMem();
void ptrMem();

#endif //SIMCACHE_MEM_H